import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.applications import VGG16

tf.config.list_physical_devices('GPU')

cifar10 = tf.keras.datasets.cifar10
(train_data, train_labels), (test_data, test_labels) = cifar10.load_data()

train_data, test_data = train_data / 255.0, test_data / 255.0

train_data = tf.image.resize(train_data, (224, 224))
test_data = tf.image.resize(test_data, (224, 224))

base_model = VGG16(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
base_model.trainable = False

model2 = tf.keras.Sequential([
    tf.keras.layers.Input(shape=(224, 224, 3)),
    keras.layers.Conv2D(64, (3, 3), activation='relu'),
    keras.layers.MaxPool2D(2, 2),
    keras.layers.Conv2D(128, (3, 3), activation='relu'),
    keras.layers.MaxPool2D(2, 2),
    keras.layers.Flatten(),
    tf.keras.layers.Dense(256, activation='relu'),
    tf.keras.layers.Dropout(0.5),
    tf.keras.layers.Dense(10, activation='softmax')
])

model2.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

history = model2.fit(train_data, train_labels, epochs=10, validation_split=0.25)

model2.evaluate(test_data, test_labels)

test_loss, test_accuracy = model2.evaluate(test_data, test_labels)

print('Test accuracy: {:.2f}%'.format(test_accuracy * 100))
