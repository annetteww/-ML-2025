﻿import numpy as np
import pandas as pd
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import tensorflow as tf
import matplotlib.pyplot as plt

# Загрузка данных о диабете
diabetes = load_diabetes()
data = diabetes.data
target = diabetes.target

# Разделение данных на обучающую и тестовую выборки
train_data, test_data, train_targets, test_targets = train_test_split(data, target, test_size=0.2, random_state=42)

# Нормализация данных
scaler = StandardScaler()
train_data = scaler.fit_transform(train_data)
test_data = scaler.transform(test_data)

model = tf.keras.Sequential([
    tf.keras.layers.Input(shape=(train_data.shape[1],)),
    tf.keras.layers.Dense(512, activation='relu'),
    tf.keras.layers.Dropout(0.2),
    tf.keras.layers.Dense(256, activation='relu'),
    tf.keras.layers.Dropout(0.3),
    tf.keras.layers.Dense(64, activation='relu'),
    tf.keras.layers.Dropout(0.5),
    tf.keras.layers.Dense(32, activation='relu'),
    tf.keras.layers.Dense(16, activation='relu'),
    tf.keras.layers.Dense(1)
])

model.compile(optimizer='adam', loss='mean_squared_error', metrics=['mape'])

history = model.fit(train_data, train_targets, epochs=100, validation_split=0.2)

loss, mae = model.evaluate(test_data, test_targets)
print(f"Mean Absolute Error on test data: {mae}")

plt.figure(figsize=(10, 5))
plt.plot(history.history['mape'], label='MAE на обучающей выборке')
plt.plot(history.history['val_mape'], label='MAE на валидационной выборке')
plt.title('Изменение MAE в процессе обучения')
plt.xlabel('Эпохи')
plt.ylabel('Mean Absolute Error')
plt.legend()
plt.grid()
plt.show()

